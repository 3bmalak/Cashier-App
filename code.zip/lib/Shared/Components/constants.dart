
// https://newsapi.org/v2/top-headlines?country=eg&category=business&apiKey=2c20ec06960b42aea81887dddcc57e0c

//base url: https://newsapi.org/
//Method : v2/top-headlines?
//query :  country=eg&category=business&apiKey=2c20ec06960b42aea81887dddcc57e0c


// https://newsapi.org/v2/everything?q=tesla&apiKey=2c20ec06960b42aea81887dddcc57e0c


//base url: https://newsapi.org/
//Method : v2/everything?
//query :  q=tesla&apiKey=2c20ec06960b42aea81887dddcc57e0c

