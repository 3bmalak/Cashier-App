import 'package:firedart/firedart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'Layout/cubit/cubit.dart';
import 'Layout/cubit/states.dart';
import 'Modules/login/app_colors.dart';
import 'Modules/login/cubit/LoginCubit.dart';
import 'Modules/login/login_screen.dart';
import 'models/getDataNodel.dart';

const dynamic apiKey = 'e7042454287a45035f10af88b03174af0ca19e0d';
const dynamic projectId = 'cashierapp-c9467';

Future<void> main() async {
  Firestore.initialize(projectId);
  print("connection done");


  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(providers: [


      BlocProvider(
        create:(context) => AppCubit()..getHistory() ,),
      BlocProvider(
        create:(context) => LoginCubit() ,),

    ],
      child: BlocConsumer<AppCubit,AppStates>(
        listener: (context, state)
        {

        },
        builder: (context, state) {
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            theme:ThemeData(
              primaryColor:AppColors.mainBlueColor,
            ),

            home: LoginScreen() ,
          );
        },
      ),
    );
  }
}
