import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../SearchScreen/Search.dart';
import '../login/app_colors.dart';

class FixedSidebar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;

    TextEditingController itemNameController = TextEditingController();
    TextEditingController itemCategoryController = TextEditingController();
    TextEditingController weightController = TextEditingController();
    TextEditingController weightUnitController = TextEditingController();
    TextEditingController priceController = TextEditingController();
    TextEditingController discountPriceController = TextEditingController();
    TextEditingController quantityController = TextEditingController();
    TextEditingController notesController = TextEditingController();

    return Container(
      width: width*0.19,
      color: AppColors.mainBlueColor,

      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 10.00,),
            Text("Welcome",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold,color: Colors.white),),
            Text("Youssef",style: TextStyle(fontSize: 20,color: Colors.white),),

            SizedBox(height: 20),
            MaterialButton(
              height: height*0.06,
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => SearchDialog(),
                );
              },
              minWidth: double.infinity,
              child: Row(children: [
                Icon(Icons.search,color: Colors.white,size: width*0.014,),
                SizedBox(width: 20,),
                Text("Search",style: TextStyle(color: Colors.white,fontSize: width*0.01),)
              ],
              ),
            ),
            SizedBox(height: 20),

            MaterialButton(
              height: height*0.06,
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return LayoutBuilder(
                      builder: (BuildContext context, BoxConstraints constraints) {
                        final maxWidth = constraints.maxWidth;
                        final maxHeight = constraints.maxHeight;
                        final dialogWidth = maxWidth > 600 ? 600 : maxWidth - 40;
                        final dialogHeight = maxHeight > 800 ? 800 : maxHeight - 40;
                        return AlertDialog(

                          title: Text('Add Item'),
                          content: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: TextFormField(
                                  controller: itemNameController,

                                  decoration: InputDecoration(labelText: 'Item Name',
                                    border:OutlineInputBorder(

                                      borderRadius: BorderRadius.circular(5),
                                      borderSide: BorderSide(
                                          color: Colors.green
                                      ),
                                    ),),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: TextFormField(

                                  controller: itemCategoryController,
                                  decoration: InputDecoration(labelText: 'Item Category',
                                    border:OutlineInputBorder(

                                      borderRadius: BorderRadius.circular(5),
                                      borderSide: BorderSide(
                                          color: Colors.green
                                      ),
                                    ),),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: TextFormField(
                                  controller: weightController,
                                  decoration: InputDecoration(labelText: 'Weight',
                                    border:OutlineInputBorder(

                                      borderRadius: BorderRadius.circular(5),
                                      borderSide: BorderSide(
                                          color: Colors.green
                                      ),
                                    ),),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: TextFormField(
                                  controller: weightUnitController,
                                  decoration: InputDecoration(labelText: 'Weight Unit',
                                    border:OutlineInputBorder(

                                      borderRadius: BorderRadius.circular(5),
                                      borderSide: BorderSide(
                                          color: Colors.green
                                      ),
                                    ),),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: TextFormField(
                                  controller: priceController,
                                  decoration: InputDecoration(labelText: 'Price',
                                    border:OutlineInputBorder(

                                      borderRadius: BorderRadius.circular(5),
                                      borderSide: BorderSide(
                                          color: Colors.green
                                      ),
                                    ),),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: TextFormField(
                                  controller: discountPriceController,
                                  decoration: InputDecoration(labelText: 'Discount Price',
                                    border:OutlineInputBorder(

                                      borderRadius: BorderRadius.circular(5),
                                      borderSide: BorderSide(
                                          color: Colors.green
                                      ),
                                    ),),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: TextFormField(
                                  controller: quantityController,
                                  decoration: InputDecoration(labelText: 'Quantity Available',
                                    border:OutlineInputBorder(

                                      borderRadius: BorderRadius.circular(5),
                                      borderSide: BorderSide(
                                          color: Colors.green
                                      ),
                                    ),),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: TextFormField(
                                  controller: notesController,
                                  decoration: InputDecoration(labelText: 'Notes',
                                    border:OutlineInputBorder(

                                      borderRadius: BorderRadius.circular(5),
                                      borderSide: BorderSide(
                                          color: Colors.green
                                      ),
                                    ),),
                                ),
                              ),
                            ],
                          ),
                          actions: <Widget>[
                            ElevatedButton(
                              onPressed: () {
                                // Add button onPressed action
                                String itemName = itemNameController.text;
                                String itemCategory = itemCategoryController.text;
                                String weight = weightController.text;
                                String weightUnit = weightUnitController.text;
                                String price = priceController.text;
                                String discountPrice = discountPriceController.text;
                                String quantity = quantityController.text;
                                String notes = notesController.text;

                                // Perform any action with the entered data (e.g., add to a list, save to database, etc.)

                                Navigator.of(context).pop();
                              },
                              child: Text('Add'),
                            ),
                            ElevatedButton(
                              onPressed: () {
                                // Cancel button onPressed action
                                Navigator.of(context).pop();
                              },
                              child: Text('Cancel'),
                            ),
                          ],
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(
                              Radius.circular(16.0),
                            ),
                          ),
                        );
                      },
                    );
                  },

                );
              },
              minWidth: double.infinity,
              child: Row(children: [
                Icon(Icons.add,color: Colors.white,size: width*0.014,),
                SizedBox(width: 20,),
                Text("Add Product",style: TextStyle(color: Colors.white,fontSize: width*0.01),)
              ],
              ),
            ),
            SizedBox(height: 20),
            MaterialButton(
              height: height*0.06,
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text('Dialog Title'),
                      content: Text('This is the content of the dialog.'),
                      actions: <Widget>[
                        ElevatedButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: Text('Close'),
                        ),
                      ],
                    );
                  },
                );
              }, minWidth: double.infinity,
              child: Row(children: [
                Icon(Icons.edit,color: Colors.white,size: width*0.014,),
                SizedBox(width: 20,),
                Text("Edit Product",style: TextStyle(color: Colors.white,fontSize: width*0.01),)
              ],
              ),
            ),
            SizedBox(height: 20),
            MaterialButton(
              height: height*0.06,
              onPressed: () {

              }, minWidth: double.infinity,
              child: Row(children: [
                Icon(Icons.add,color: Colors.white,size: width*0.014,),
                SizedBox(width: 20,),
                Text("Remove Product",style: TextStyle(color: Colors.white,fontSize: width*0.01),)
              ],
              ),
            ),
            Spacer(),
            MaterialButton(
              height: height*0.06,
              onPressed: () {

              }, minWidth: double.infinity,
              child: Row(children: [
                Icon(Icons.logout_outlined,color: Colors.white,size: width*0.014,),
                SizedBox(width: 20,),
                Text("Logout",style: TextStyle(color: Colors.white,fontSize: width*0.01),)
              ],
              ),
            ),

          ],
        ),
      ),
    );
  }
}


