import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled1/models/HistoryModel.dart';
import '../../Layout/cubit/cubit.dart';
import '../../Layout/cubit/states.dart';
import '../../Shared/Components/Component.dart';
import '../../models/ProductsModel.dart';
import '../../models/getDataNodel.dart';
import '../login/app_colors.dart';

TextEditingController c =TextEditingController();

class HistoryDialog extends StatelessWidget {
  TextEditingController controlleruser=TextEditingController();
  TextEditingController controller=TextEditingController();
  TextEditingController controllerclient=TextEditingController();
  TextEditingController controllerstart=TextEditingController();
  TextEditingController controllerend=TextEditingController();@override
  Widget build(BuildContext context) {
    // Get the screen size to make the dialog responsive
    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;


    return BlocConsumer<AppCubit,AppStates>(
      listener: (context, state) {

      },
      builder: (context, state) {

        AppCubit cubit=AppCubit.get(context);
        return Dialog(

          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(
              Radius.circular(16.0),
            ),
          ),
          child: Container(
            height: height*.8,
            width: width*.6,
            padding: EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [

                SizedBox(height: 20),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(width: 15,),
                    if(cubit.selectedOption=="User Name")
                        Column(mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("UserName: ",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 12),),
                        SizedBox(height: 5,),
                        Container(
                          width: 110,
                          height: 30,
                          child: TextField(
                            controller: controlleruser,
                            style: TextStyle(fontSize: 14),
                            textAlign: TextAlign.center,
                            keyboardType: TextInputType.number,

                            onSubmitted: (value) {

                            },
                            decoration: const InputDecoration(
                              contentPadding: EdgeInsets.zero,
                              border: OutlineInputBorder(),
                              hintText: '',
                            ),
                          ),
                        ),
                      ],
                    ),

                    if(cubit.selectedOption=="Client Name")
                      Column(mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Client Name: ",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 12),),
                          SizedBox(height: 5,),
                          Container(
                            width: 110,
                            height: 30,
                            child: TextField(
                              controller: controllerclient,
                              style: TextStyle(fontSize: 14),
                              textAlign: TextAlign.center,
                              keyboardType: TextInputType.number,

                              onSubmitted: (value) {

                              },
                              decoration: const InputDecoration(
                                contentPadding: EdgeInsets.zero,
                                border: OutlineInputBorder(),
                                hintText: '',
                              ),
                            ),
                          ),
                        ],
                      ),

                    if(cubit.selectedOption=="Date")
                      Row(
                        children: [
                          Column(mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Start Date ",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 12),),
                              SizedBox(height: 5,),
                              Container(
                                width: 110,
                                height: 30,
                                child: TextField(
                                  controller: controllerstart,
                                  style: TextStyle(fontSize: 14),
                                  textAlign: TextAlign.center,
                                  keyboardType: TextInputType.number,

                                  onSubmitted: (value) {

                                  },
                                  decoration: const InputDecoration(
                                    contentPadding: EdgeInsets.zero,
                                    border: OutlineInputBorder(),
                                      hintText: 'DD/MM/YYYY',
                                      hintStyle: TextStyle(fontSize: 12)
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(width: 10,),
                          Column(mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("End Date: ",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 12),),
                              SizedBox(height: 5,),
                              Container(
                                width: 110,
                                height: 30,
                                child: TextField(
                                  controller: controllerend,
                                  style: TextStyle(fontSize: 14),
                                  textAlign: TextAlign.center,
                                  keyboardType: TextInputType.number,

                                  onSubmitted: (value) {

                                  },
                                  decoration: const InputDecoration(
                                    contentPadding: EdgeInsets.zero,
                                    border: OutlineInputBorder(),
                                    hintText: 'DD/MM/YYYY',
                                    hintStyle: TextStyle(fontSize: 12)
                                  ),
                                ),
                              ),
                            ],
                          ),

                        ],
                      ),



                    SizedBox(width: 20),
                    Container(
                      height:  height*.04,
                      width: width*.04,
                      child: ElevatedButton(

                        onPressed: () {
                          cubit.filterHistory(cubit.selectedOption, controlleruser.text);
                        },
                        child: Center(child: Text("Filter",style: TextStyle(fontSize: width*0.008),)),
                        style: ButtonStyle(
                          padding: MaterialStateProperty.all<EdgeInsetsGeometry>(EdgeInsets.zero),
                          alignment: Alignment.centerLeft, // You can change the alignment as per your requirement
                          backgroundColor: MaterialStateProperty.all<Color>(Colors.blue), // Customize the button color if needed
                          // Other style properties like textStyle, elevation, shape, etc. can also be customized here.
                        ),
                      ),
                    ),

                    SizedBox(width: 20),
                    Column(mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        SizedBox(height: 30,),
                        Container(height: 40,
                          child: DropdownButton<String>(
                            value: cubit.selectedOption,
                            onChanged: (newValue)
                            {
                              AppCubit.get(context).changeDropDown(newValue);
                            },

                            items: <String>[
                              'User Name',
                              'Date',
                              'Client Name',
                              // 'Option 4',
                            ].map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Center(child: Text(value,style: TextStyle(fontSize: 10,fontWeight: FontWeight.bold),)),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),

                SizedBox(height: 10),
                // Replace this ListView with your actual search results ListView
                // For demonstration purposes, I'm just showing an empty ListView.
              Expanded(
                    child: ListView.separated(
                      padding: const EdgeInsets.all(1),
                      itemCount:cubit.d.length,
                      itemBuilder: (BuildContext context, int index) =>
                         HistoryList(height,width,context,cubit.d[index]),
                      separatorBuilder: (BuildContext context, int index) =>
                          Container(),
                    )
                ),

                SizedBox(height: 10),
                Row(mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      child: Text("Close"),
                    ),
                  ],
                ),
              ],
            ),
          ),

        );
      },
    );
  }
}

Widget HistoryList(height,width,context,HistoryModel model) => Padding(
  padding: const EdgeInsets.all(7.0),
  child: Container(
    height: MediaQuery.of(context).size.height*.06,
    width: double.infinity,
    decoration: BoxDecoration(boxShadow: [
      BoxShadow(
        color: Colors.grey.withOpacity(0.5), //color of shadow
        spreadRadius: 1, //spread radius
        blurRadius: 5, // blur radius
        offset: const Offset(0, 1), // changes position of shadow
      ),
    ], borderRadius: BorderRadius.circular(10.0), color: Colors.white),
    child: Row(
      children: [
        const Padding(
          padding:
          EdgeInsetsDirectional.only(start: 15.0, end: 15.0),
          child: Icon(
            Icons.wysiwyg_outlined,
            size:18,
          ),
        ),
        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    "User name: ${model.username}, " ,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.bold,fontSize: 13 ),
                  ),
                  SizedBox(width: 20,),
                  Text(
                    "Client name ${model.clientName}",
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12 ),
                  ),
                  SizedBox(width: 20,),
                  Text(
                    "date ${model.date}",
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12 ),
                  ),
                ],
              ),
              const SizedBox(
                height: 3.0,
              ),
              Row(
                children: [
                  Text(
                    " total cost: ${model.totalcost.toString()} LE",
                    style: const TextStyle(
                        color: AppColors.blueDarkColor,
                        fontWeight: FontWeight.bold,fontSize: 12),
                  ),
                  SizedBox(
                    width: 20.0,
                  ),
                  Text(
                    "payed ${model.payed.toString()} LE",
                    style: const TextStyle(
                        color: AppColors.blueDarkColor,
                        fontWeight: FontWeight.bold,fontSize: 12),
                  ),

                  // SizedBox(width: 80,),
                ],
              ),
            ],
          ),
        ),

        // Container(
        //   child: Row(
        //     children: [
        //       // Text("Quantity "),
        //
        //       Container(height: height*.03,
        //           width:height*.04 ,
        //           color: Colors.grey[100],
        //           child: Center(child: Text(model.quantity.toString()))
        //       )
        //     ],
        //   ),
        // ),
        Padding(
          padding: const EdgeInsetsDirectional.only(start: 10,end: 10.0),
          child: IconButton(
            icon: const Icon(Icons.details_outlined),
            color: Colors.black,
            onPressed: () {
              // showCustomDialog(height,width,context, model,controller);
            },
          ),
        ),
      ],
    ),
  ),
);


// void showCustomDialog(height,width,context, GetDataModel model ,TextEditingController controller) =>
//     showDialog(
//       context: context,
//       // barrierDismissible: false,
//       builder: (context) =>Dialog(
//         shape: RoundedRectangleBorder(
//           borderRadius: BorderRadius.circular(16),
//         ),
//         child: Container(
//           height: height*.45,
//           width: width*.1,
//           padding: EdgeInsets.all(20),
//
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               SizedBox(height: 12),
//               const Text(
//                 'Details',
//                 style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
//               ),
//               SizedBox(height: height*.03),
//               Text(
//                 'Name: ${model.itemName}',
//                 textAlign: TextAlign.center,
//                 style: TextStyle(fontSize: 20),
//               ),
//               SizedBox(height: 12),
//               Text(
//                 ' Price: ${model.price} \$',
//                 textAlign: TextAlign.center,
//                 style: TextStyle(fontSize: 20),
//               ),
//               SizedBox(height: 12),
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   const Text("Quantity: ",
//                     textAlign: TextAlign.center,
//                     style: TextStyle(fontSize: 20),),
//                   SizedBox(width: 5,),
//                   Container(
//                     width: 30,
//                     height: 30,
//                     child:  TextField(
//                       controller: controller,
//                       style: TextStyle(
//                           fontSize: 14
//                       ),
//
//                       textAlign: TextAlign.center,
//
//
//                       // Add your TextField properties here
//                       decoration: InputDecoration(
//                         contentPadding: EdgeInsets.zero, // Remove internal padding
//                         border: OutlineInputBorder(),
//                         hintText: '1',
//                       ),
//                     ),
//                   ),
//
//
//
//                   SizedBox(width: 10),
//                 ],
//               ),
//
//               SizedBox(height: 20,),
//               Spacer(),
//               Row(mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//
//                   ElevatedButton(
//                     onPressed: () {
//                       controller.text="";
//                       Navigator.of(context).pop();
//                     },
//                     child: Text("Cancel"),
//                   ),
//
//                 ],
//               ),
//
//
//             ],
//           ),
//         ),
//       ) ,
//       // child: ,
//     );
