
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../Shared/Components/Component.dart';
import '../../../Shared/Network/End_Points/end_points.dart';
import '../../../Shared/Network/local/cache_Helper.dart';
import 'LoginStates.dart';






class LoginCubit extends Cubit<LoginStates>{
  LoginCubit():super(ShopLoginInitState());
  static LoginCubit get(context) => BlocProvider.of(context);
  bool isPasswordIconChecked=true;
  bool isCreated=false;

  void createIconEye(){
    isCreated=true;
    emit(isPasswordIconCreatedLoginState());

  }
  void ChangePasswordVisability(){
    isPasswordIconChecked =! isPasswordIconChecked;
    emit(isPasswordIconCheckedLoginState());
  }


  void Changestate(){
    emit(ShopLoginInitState());
  }


}