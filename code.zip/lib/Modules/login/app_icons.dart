import 'package:flutter/material.dart';

class AppIcons {
  static const String emailIcon = 'assets/images/EmailIcon.png';
  static const String lockIcon = 'assets/images/lockIcon.png';
  static const String eyeIcon = 'assets/images/EyeIcon.png';
}