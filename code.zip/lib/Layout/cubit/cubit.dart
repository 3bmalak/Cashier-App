
import 'package:firedart/firestore/firestore.dart';
import 'package:flutter/material.dart';
import 'package:bloc/bloc.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled1/Layout/cubit/states.dart';


import '../../models/HistoryModel.dart';
import '../../models/ProductsModel.dart';
import '../../models/getDataNodel.dart';
import '../../models/tableViewModel.dart';





class AppCubit extends Cubit<AppStates>
{
  AppCubit() : super(AppInitState());
  static AppCubit get(context) => BlocProvider.of(context);


int count =1;

void increaseCount(){
    count++;
    emit(increaseSuccessfulystate());
  }
  List<GetDataModel> allData=[];

void getFirebase() async {
    WidgetsFlutterBinding.ensureInitialized();
    emit(DataLoadingState());


    await Firestore.instance.collection('data').get().then((page)
    {
      var documents = page.toList();
      for (var document in documents) {
        allData.add(GetDataModel.fromJson(document));
        // print(allData[0].itemName);
        // print('Document: ${document.map}');
        emit(RowAddedSuccessfulState());

      }
      emit(DataSuccessfulState());


    });

  }


List<HistoryModel> historyData=[];

Future<void> getHistory() async {
  WidgetsFlutterBinding.ensureInitialized();
  emit(HistoryDataLoadingState());


  await Firestore.instance.collection('ordersHistory').get().then((page)
  async {
    var documents = page.toList();
    for (var document in documents) {
      HistoryModel s=HistoryModel.fromJson(document);
      // print(s.date);

      await Firestore.instance.collection('ordersHistory').document(s.cartid).collection("orderProducts").get().then((page)
      {
        var documents = page.toList();
        for (var document in documents) {
          s.data.add(Products.fromJson(document));
        }
      });
       historyData.add(s);
      emit(HistoryRowAddedSuccessfulState());
    }
    emit(HistoryDataSuccessfulState());
  });
}

  void decreaseCount()
  {
    count--;
    emit(decreaseSuccessfulystate());
  }

  List<GetDataModel> cart=[];
  List<TableViewModel> cart2=[];

  double totalCost=0;
  void addToCart(GetDataModel model,int q)
  {
    bool x= false;
    for(var i in cart2)
      {
        if(model.itemName==i.itemName){
          i.quantity+=q;
          recalculateTotalCost();
          emit(ProductAddedSuccessfulState());
          x=true;
        }
      }
    if(x==false){
    cart.add(model);
    cart2.add(
        TableViewModel(
            model.code,
            model.itemWeight,
            model.weightUnit,
            model.category,
            model.price,
            model.discountPrice,
            model.itemName,
            q,
            model.isChecked
        )
    );
    totalCost+=int.parse(model.price.toString())*q;
    emit(ProductAddedSuccessfulState());
    }

  }

  void changeQuantity(model, int old,int New){

    for(var i in allData){
      if(i.itemName==model.itemName){
        if(old<New)
        {
          i.quantity-=(New-old);
        }
        else if(old>New)
        {
          i.quantity+=(old-New);
        }
        emit(changeQuantitySuccessfulState());
        break;

      }
    }
  }

  void improveQuantity(TableViewModel model,){
    for(var i in allData){
      if(i.itemName==model.itemName){
        i.quantity+=model.quantity;
        break;

      }  }
    }


  void removeFromCart(TableViewModel model,int q) {
    // cart.remove(model);
    cart2.remove(TableViewModel(model.code,
        model.itemWeight,
        model.weightUnit,
        model.category,
        model.price,
        model.discountPrice,
        model.itemName,
        q,
        model.isChecked
    ));

    totalCost-=int.parse(model.price.toString())*q;
    emit(ProductRemovedSuccessfulState());

  }

  void recalculateTotalCost(){
    totalCost=0;
    for(var i in cart2){
      totalCost+=i.price*i.quantity;
      emit(recalculateTotalCostSuccessfulState());

    }
  }



  void changeState(){
    emit(SearchSuccessfulState());
  }
   String selectedOption="User Name";

  void changeDropDown(s){
    selectedOption=s;
    emit(SearchSuccessfulState());
  }


  List<HistoryModel> d=[];
 void filterHistory(type,data)
 {
   d=[];
   for(var i in historyData){
     if(type=="User Name"){
       if(data==i.username){
         d.add(i);
        }
     }
     if(type=="Client Name"){
       if(data==i.clientName){
         d.add(i);
        }
     }
     if(type=="Date"){
       if(data==i.clientName){
         d.add(i);
        }
     }
   }
   // print(d);
   emit(DataLoadingState());


 }


  List<GetDataModel> searchData =[];

  void getSearch(data) {
    for (var ss in allData) {
      if (ss.itemName.toLowerCase().contains(data.toLowerCase())) {
        searchData.add(ss);
        emit(SearchSuccessfulState());

      }
    }
  }

  void saveHistory(username,cartid,products,payed,totalcost,date,  clientName , clientPhoneNumber ){
    HistoryModel s=HistoryModel(username: username, cartid: cartid, products: products, payed: payed, totalcost: totalcost, date: date,clientName: clientName,clientPhoneNumber:clientPhoneNumber );
    s.toMap();
    emit(historyAddedSuccessfully());
  }


  String barCodeRes="";
  Future<void> ScanBarcode() async{

    await FlutterBarcodeScanner.scanBarcode(
        "#ff6666",
        "Cancel",
        true,
        ScanMode.BARCODE
    ).then((value){
      print(value);
      barCodeRes=value.toString();
      emit(ScannedSuccessfulystate());
    }
    ).catchError((onError){
      print(onError.toString());
      barCodeRes="Erorr!!!";
      emit(ScannedErrorstate());

    });

  }

}


