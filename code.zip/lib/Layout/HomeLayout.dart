// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:untitled3/Layout/cubit/cubit.dart';
// import 'package:untitled3/Layout/cubit/states.dart';
// import 'package:untitled3/Modules/SearchScreen/SearchScreen.dart';
// import 'package:untitled3/Modules/login/app_colors.dart';
// import 'package:untitled3/Shared/Components/Component.dart';
// import 'package:untitled3/models/ProductsModel.dart';
//
// class CashierApp extends StatelessWidget {
//   const CashierApp({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return BlocConsumer<AppCubit,AppStates>(
//       listener: (context, state) {
//
//       },
//       builder: (context, state) {
//         List<ProductModel> products = [
//
//           ProductModel(name: 'Apple', code: '123', price: 1.99),
//           ProductModel(name: 'Banana', code: '124', price: 0.99),
//           ProductModel(name: 'Orange', code: '125', price: 1.49),
//           ProductModel(name: 'Grapes', code: '126', price: 2.99),
//           // Add more products here as needed.
//         ];
//
//         return  Scaffold(
//           drawer:  Drawer(
//         child: ListView(
//         padding: EdgeInsets.zero,
//           children: [
//             DrawerHeader(
//
//               decoration: BoxDecoration(
//                 color: AppColors.mainBlueColor,
//               ),
//               child: Text(
//                 'Sidebar Header',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 24,
//                 ),
//               ),
//             ),
//             ListTile(
//               leading: Icon(Icons.add_circle_outline),
//               title: Text('Add Product'),
//               onTap: () {
//                 // Handle the onTap event to navigate to the home page
//               },
//             ),
//             ListTile(
//               leading: Icon(Icons.edit),
//               title: Text('Edit Product'),
//               onTap: () {
//                 // Handle the onTap event to navigate to the settings page
//               },
//             ),
//             ListTile(
//               leading: Icon(Icons.remove_circle_outline),
//               title: Text('Remove Product'),
//               onTap: () {
//                 // Handle the onTap event to navigate to the settings page
//               },
//             ),
//           ],
//         ),
//         ),
//           backgroundColor: Colors.white,
//           appBar: AppBar(
//
//             backgroundColor: Colors.deepOrange,
//             title: Text(
//               "Cashier mobile",
//               style: TextStyle(
//               ),
//             ),
//             actions: [
//               InkWell(
//                 onTap: () {
//                   // Get.to(
//                   //   History(),
//                   // );
//                 },
//                 child: Icon(Icons.history, ),
//               ),
//               SizedBox(
//                 width: 15,
//               ),
//             ],
//           ),
//           body:
//           Column(
//             children: [
//
//               Expanded(
//                   child: ListView.separated(
//                     padding: const EdgeInsets.all(1),
//                     itemCount:products.length ,
//                     itemBuilder: (BuildContext context, int index) =>
//                         bulidLocationList(context,products[index]),
//                     separatorBuilder: (BuildContext context, int index) =>
//                         Container(),
//                   )
//               ),
//             ],
//           ),
//
//           floatingActionButton:    Row(
//             children: [
//               Padding(
//                 padding: const EdgeInsets.only(left: 40 ),
//                 child: Container(
//                   width: 110,
//                   height: 45,
//                   decoration: BoxDecoration(
//                    boxShadow: [
//                     BoxShadow(
//                       color: Colors.grey.withOpacity(0.5), //color of shadow
//                       spreadRadius: 4, //spread radius
//                       blurRadius: 5, // blur radius
//                       offset: const Offset(0, 1), // changes position of shadow
//                     ),
//                   ],
//
//                       borderRadius:
//                       BorderRadius.circular(30.0),
//                       color: Colors.deepOrange
//                   ),
//                   child: Center(
//                     child: Text("5.28 \$ ",
//                       style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 18),
//                     ),
//                   ),
//
//                 ),
//               ),
//               Spacer(),
//               FloatingActionButton(
//                 backgroundColor: Colors.deepOrange,
//                 onPressed: () {
//                   navigatorTo(context, SearchScreen());
//                 },
//                 child: Icon(
//                   Icons.add,
//                   color: Colors.white,
//                 ),
//               ),
//             ],
//           ),
//         );
//       },
//     );
//   }
// }
//
// Widget bulidSearchList(context,ProductModel model) => Padding(
//   padding: const EdgeInsets.all(7.0),
//   child: Container(
//     height: 70.0,
//     width: double.infinity,
//     decoration: BoxDecoration(boxShadow: [
//       BoxShadow(
//         color: Colors.grey.withOpacity(0.5), //color of shadow
//         spreadRadius: 1, //spread radius
//         blurRadius: 5, // blur radius
//         offset: const Offset(0, 1), // changes position of shadow
//       ),
//     ], borderRadius: BorderRadius.circular(10.0), color: Colors.white),
//     child: Row(
//       children: [
//         const Padding(
//           padding:
//           EdgeInsetsDirectional.only(start: 15.0, end: 15.0),
//           child: Icon(
//             Icons.wysiwyg_outlined,
//           ),
//         ),
//         Expanded(
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(
//                 model.name ,
//                 maxLines: 1,
//                 overflow: TextOverflow.ellipsis,
//                 style: const TextStyle(fontWeight: FontWeight.bold),
//               ),
//               const SizedBox(
//                 height: 10.0,
//               ),
//               Row(
//                 children: [
//                   Text(
//                     " ${model.price.toString()} \$",
//                     style: const TextStyle(
//                         color: Colors.deepOrange,
//                         fontWeight: FontWeight.bold),
//                   ),
//                   // SizedBox(width: 80,),
//                   Spacer(),
//
//                 ],
//               ),
//             ],
//           ),
//         ),
//         Padding(
//           padding: const EdgeInsetsDirectional.only(end: 10.0),
//           child: IconButton(
//             icon: const Icon(Icons.delete),
//             color: Colors.red,
//             onPressed: () {
//               print(MediaQuery.of(context).size);
//             },
//           ),
//         ),
//       ],
//     ),
//   ),
// );
