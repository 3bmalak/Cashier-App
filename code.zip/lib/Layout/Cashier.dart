import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:uuid/uuid.dart';
import '../Modules/HistoryScreen/History.dart';
import '../Modules/SideBar/SiedBar.dart';
import '../Shared/Components/Component.dart';
import '../models/getDataNodel.dart';
import '../models/tableViewModel.dart';
import 'cubit/cubit.dart';
import 'cubit/states.dart';

class CashierrApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: CashierScreen(),
    );
  }
}
class CashierScreen extends StatelessWidget {
  final List<String> columnHeaders = ['Item Name', 'Category', 'Weight', 'Price', 'Discount',"Count",'Delete'];
  @override
  Widget build(BuildContext context) {

    double height = MediaQuery.of(context).size.height;
    double width  =  MediaQuery.of(context).size.width;
    return BlocConsumer<AppCubit,AppStates>(
      listener: (context, state) {

      },
      builder: (context, state) {


      AppCubit cubit=AppCubit.get(context);
        return Scaffold(
          body: Column(
            children: [


              Expanded(
                child: Container(
                  color: Colors.grey[400],
                  child: Row(
                    children: [
                      FixedSidebar(),
                      Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: width*0.77,
                              color: Colors.white,
                              height: height*.65,

                              child: Column(
                                children: [
                                  Container(
                                    width:width*0.77,
                                    padding: const EdgeInsets.all(10),

                                    child:
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          width: width*.1,
                                          height: height*.04,
                                          // color: Colors.white,
                                          child: TextField(
                                            style: TextStyle(
                                                fontSize: 14
                                            ),

                                            textAlign: TextAlign.center,
                                            // Add your TextField properties here
                                            decoration: InputDecoration(
                                              fillColor: Colors.white,
                                              contentPadding: EdgeInsets.zero, // Remove internal padding
                                              border: OutlineInputBorder(),
                                              hintText: 'Phone Number',
                                            ),
                                          ),
                                        ),
                                        SizedBox(width: width*.01,),
                                        Container(
                                          height:  height*.04,
                                          width: width*.04,
                                          child: ElevatedButton(

                                            onPressed: () {
                                            },
                                            child: Center(child: Text("Scan",style: TextStyle(fontSize: width*0.008),)),
                                            style: ButtonStyle(
                                              padding: MaterialStateProperty.all<EdgeInsetsGeometry>(EdgeInsets.zero),
                                              alignment: Alignment.centerLeft, // You can change the alignment as per your requirement
                                              backgroundColor: MaterialStateProperty.all<Color>(Colors.blue), // Customize the button color if needed
                                              // Other style properties like textStyle, elevation, shape, etc. can also be customized here.
                                            ),
                                          ),
                                        ),
                                        // Spacer(),
                                        SizedBox(width:width*.007),
                                        Container(
                                          height:  height*.04,
                                          width: width*.07,
                                          child: ElevatedButton(
                                            style: ButtonStyle(
                                              padding: MaterialStateProperty.all<EdgeInsetsGeometry>(EdgeInsets.zero),
                                              alignment: Alignment.centerLeft, // You can change the alignment as per your requirement
                                              backgroundColor: MaterialStateProperty.all<Color>(Colors.blue), // Customize the button color if needed
                                              // Other style properties like textStyle, elevation, shape, etc. can also be customized here.
                                            ),


                                            onPressed: () {
                                            },

                                            child: Center(child: Text("New Client",style: TextStyle(fontSize: width*0.008),)),
                                          ),
                                        ),
                                        Spacer(),
                                        Container(
                                          height:  height*.04,
                                          width: width*.07,
                                          child: ElevatedButton(
                                            style: ButtonStyle(
                                              padding: MaterialStateProperty.all<EdgeInsetsGeometry>(EdgeInsets.zero),
                                              alignment: Alignment.centerLeft, // You can change the alignment as per your requirement
                                              backgroundColor: MaterialStateProperty.all<Color>(Colors.blue), // Customize the button color if needed
                                              // Other style properties like textStyle, elevation, shape, etc. can also be customized here.
                                            ),


                                            onPressed: () {
                                              showDialog(
                                                context: context,
                                                builder: (context) => HistoryDialog(),
                                              );
                                            },

                                            child: Center(child: Text("History",style: TextStyle(fontSize: width*0.008),)),
                                          ),
                                        ),

                                      ],),
                                  ),


                                  Container(
                                    // width: width/1.3 ,
                                    width: width*0.77,
                                    padding: const EdgeInsets.only(left: 5.0,right: 5),
                                    height: height*.57,
                                    color: Colors.grey[200],
                                    child: cubit.cart2.length!=0?
                                    SingleChildScrollView(
                                      scrollDirection: Axis.vertical,
                                      child:  DataTable(
                                        dataTextStyle: TextStyle(
                                            fontSize: 14,
                                            color: Colors.black
                                        ),
                                        headingRowHeight: 40,
                                        dataRowHeight: 40,
                                        dataRowColor: MaterialStateColor.resolveWith((states) => Colors.white70), // Set the header row color here
                                        dividerThickness: 2, // Set the thickness of the vertical and horizontal dividers
                                        columns: buildDataColumns(columnHeaders),
                                        rows:  buildDataRows(context,cubit.cart2),
                                      )
                                    ):
                                    Center(
                                       child: Text(
                                           "Empty !",
                                            style: TextStyle(fontSize: width*.03,fontWeight: FontWeight.bold),
                                       ),
                                    ),

                                  ),
                                ],
                              ),
                            ),
                            Container(
                              width: width*0.77,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Container(
                                    height: height*.04,
                                    width: width*0.08,
                                    color: Colors.grey[300],
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Text("total cost  ",style: TextStyle(fontSize: width*0.008),),
                                        Text(AppCubit.get(context).totalCost.toString(),style: TextStyle(fontWeight: FontWeight.bold,fontSize: width*0.01),),
                                      ],
                                    ),)

                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          floatingActionButton:    Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              // Spacer(),

              DefaultButton(
                text: "Check Out",
                function: ()
                {

                  DateTime now = DateTime.now();
                  String formattedDate = "${now.day}/${now.month}/${now.year} \n ${now.hour}:${now.minute}";
                  // String formattedTime = "${now.hour}:${now.minute}";
                  print(formattedDate);
                  String uniqueId = Uuid().v4();
                  print(uniqueId);
                  AppCubit.get(context).saveHistory("youssef", uniqueId, AppCubit.get(context).cart2, 250, AppCubit.get(context).totalCost, formattedDate,"ahmed","01200393020");

                  // print(formattedTime);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  List<DataColumn> buildDataColumns(List<String> columnHeaders) {
    return columnHeaders
        .map((header) => DataColumn(label: Text(header)))
        .toList();
  }

  List<DataRow> buildDataRows(BuildContext context, List<TableViewModel> rowData) {
    return rowData.asMap().entries.map((entry) {
      int index = entry.key;
      TableViewModel data = entry.value;

      return DataRow(
        cells: [
          DataCell(
            Container(
              width: MediaQuery.of(context).size.width * 0.19,
              child: Text(data.itemName,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize:MediaQuery.of(context).size.width*.008 ),
              ),
            ),
          ),
          DataCell(
            Container(
              width: MediaQuery.of(context).size.width * 0.1,
              child: Text(data.category,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize:MediaQuery.of(context).size.width*.008 ),),
            ),
          ),
          DataCell(Text(data.itemWeight.toString()+"  "+data.weightUnit.toString(),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize:MediaQuery.of(context).size.width*.008 ),
          ),
          ),
          DataCell(
              Text(
              data.isChecked ?  data.discountPrice.toString():data.price.toString() )),
          DataCell(
            Checkbox(
              value: data.isChecked,
              onChanged: (value) {
                data.isChecked=value!;
                if(data.isChecked){
                  if(data.discountPrice!=""){
                    AppCubit.get(context).totalCost-=(data.price*data.quantity-data.discountPrice*data.quantity);
                  }
                }
                else{
                  AppCubit.get(context).totalCost+=(data.price*data.quantity-data.discountPrice*data.quantity);

                }
                AppCubit.get(context).changeState();
              },
            ),
          ),
          DataCell(
            Container(
              width: 30,
              height: 30,
              child: TextField(
                controller: TextEditingController(text: data.quantity.toString()),
                style: TextStyle(fontSize: 14),
                textAlign: TextAlign.center,
                keyboardType: TextInputType.number,

                onSubmitted: (value) {

                  AppCubit.get(context).changeQuantity(data,data.quantity,int.parse(value));
                  data.quantity = int.parse(value);
                  AppCubit.get(context).recalculateTotalCost();
                },
                decoration: const InputDecoration(
                  contentPadding: EdgeInsets.zero,
                  border: OutlineInputBorder(),
                  hintText: '1',
                ),
              ),
            ),
          ),
          DataCell(
            IconButton(
              icon: Icon(Icons.delete, color: Colors.redAccent),
              onPressed: () {
                // Delete the row when the delete button is pressed
                AppCubit.get(context).changeState();
                AppCubit.get(context).removeFromCart(data,data.quantity);
                AppCubit.get(context).improveQuantity(data);
                rowData.removeAt(index);
                AppCubit.get(context).changeState();
              },
            ),
          ),
        ],
      );
    }).toList();
  }
}
