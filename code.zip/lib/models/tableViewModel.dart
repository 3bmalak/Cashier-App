class TableViewModel {
  dynamic code;
  dynamic itemWeight;
  dynamic weightUnit;
  dynamic category;
  dynamic price;
  dynamic discountPrice;
  dynamic itemName;
  dynamic quantity;
  bool isChecked=false;


  TableViewModel(
      this.code,
      this.itemWeight,
      this.weightUnit,
      this.category,
      this.price,
      this.discountPrice,
      this.itemName,
      this.quantity,
      this.isChecked
      );

  TableViewModel.fromJson(var json)
  {
    code= json['code'];
    itemWeight= json['itemWeight'];
    category= json['category'];
    weightUnit= json['weightUnit'];
    price= json['price'];
    discountPrice= json['discountPrice'];
    itemName= json['itemName'];
    quantity= json['quantity'];

  }
  Map<String, dynamic> toMap()
  {
    return {
      'code':code,
      'itemWeight' : itemWeight,
      'category' : category,
      'weightUnit' : weightUnit,
      'price' : price,
      'discountPrice' : discountPrice,
      'itemName' : itemName,
      'quantity' : quantity,
    };
  }
}