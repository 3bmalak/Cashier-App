class GetDataModel {
  dynamic code;
  dynamic notes;
  dynamic itemWeight;
  dynamic weightUnit;
  dynamic category;
  dynamic price;
  dynamic discountPrice;
  dynamic itemName;
  dynamic quantity;
  bool isChecked=false;


  GetDataModel.fromJson(var json)
  {
    code= json['code'];
    notes= json['notes'];
    itemWeight= json['itemWeight'];
    category= json['category'];
    weightUnit= json['weightUnit'];
    price= json['price'];
    discountPrice= json['discountPrice'];
    itemName= json['itemName'];
    quantity= json['quantity'];

  }
  Map<String, dynamic> toMap()
  {
    return {
      'code':code,
      'notes' : notes,
      'itemWeight' : itemWeight,
      'category' : category,
      'weightUnit' : weightUnit,
      'price' : price,
      'discountPrice' : discountPrice,
      'itemName' : itemName,
      'quantity' : quantity,
    };
  }
}