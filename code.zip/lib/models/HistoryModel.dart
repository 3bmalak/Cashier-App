import 'package:firedart/firestore/firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:untitled1/models/tableViewModel.dart';
import 'package:uuid/uuid.dart';

// late List<Products> h;


class HistoryModel
{
  dynamic username;
  dynamic cartid;
  dynamic totalcost;
  dynamic payed;
   List<Products> data=[] ;
  List<TableViewModel>? products ;
  dynamic date;
  dynamic clientName;
  dynamic clientPhoneNumber;


  HistoryModel({
    required this.username,
    required this.cartid,
    required this.products,
    required this.payed,
    required this.totalcost,
    required this.clientName,
    required this.clientPhoneNumber,
    required this.date,

  });

  HistoryModel.fromJson(dynamic json)
   {
   username= json['username'];
    totalcost= json['totalcost'];
    cartid= json['cartid'];
    payed= json['payed'];
    clientName= json['clientName'];
   date= json['date'];
    clientPhoneNumber= json['clientPhoneNumber'];






  }



  void toMap()
  {
    List<Map<String, dynamic>> dataToBeSent=[];
    Map<String, dynamic>? youssef ;
    Map<String, dynamic>? data ;
    youssef={
      'username':username,
      'payed':payed,
      'cartid':cartid,
      'totalcost':totalcost,
      'clientName':clientName,
      'date':date,
      'clientPhoneNumber':clientPhoneNumber,
    };
    Firestore.instance.collection('ordersHistory').document(cartid).set(youssef);
    // print(products?.length);

    for(int a = 0; a < products!.length; a++){
      data={
        "itemName": products?[a].itemName,
        "quantity": products?[a].quantity,
        "code": products?[a].code,
        "category": products?[a].category,
        "price": products?[a].price,
      };
      String uniqueId = Uuid().v4();
      Firestore.instance.collection('ordersHistory').document(cartid).collection("orderProducts").document(uniqueId).set(data);


    }

  }
}



class Products
{
  dynamic category;
  dynamic code;
  dynamic quantity;
  dynamic itemName;
  dynamic price;

  Products.fromJson(dynamic json)
  {
    category= json['category'];
    code= json['code'];
    itemName= json['itemName'];
    price= json['price'];
    quantity= json['quantity'];
  }
}