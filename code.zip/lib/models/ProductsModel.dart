class ProductModel {
  String name;
  String code;
  double price;
  int count=1;

  ProductModel({required this.name, required this.code, required this.price});
}